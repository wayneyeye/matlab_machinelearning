function f = fex3(x)
% function f = fex3(x)

f = 2.5 * sinh (x/4) - 1;