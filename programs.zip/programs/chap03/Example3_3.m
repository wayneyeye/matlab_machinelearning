% Script for Example 3.3

format long g
[x,n] = bisect('fex3',-10,10,fex3(-10),fex3(10),1.e-10)