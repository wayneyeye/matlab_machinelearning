function f = func2d(x,y)

f = sin(x+y).*exp(x-y);